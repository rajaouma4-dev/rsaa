//! One Rust WebRTC peer per connected mobile client. Users never P2P-connect to each other.
use crate::{
    db::Store,
    protocol::{DataChannelClientFrame, DataChannelServerFrame, ServerFrame},
};
use anyhow::{Context, Result};
use base64::{engine::general_purpose::STANDARD, Engine as _};
use async_trait::async_trait;
use serde_json::json;
use std::{collections::HashMap, sync::Arc};
use tokio::{sync::{mpsc, Mutex}, time::{sleep, Duration}};
use webrtc::{
    data_channel::{DataChannel, DataChannelEvent},
    peer_connection::{
        PeerConnection, PeerConnectionBuilder, PeerConnectionEventHandler,
        RTCConfigurationBuilder, RTCIceServer, RTCPeerConnectionIceEvent,
        RTCSessionDescription,
    },
};

pub type LiveChannels = Arc<Mutex<HashMap<String, Arc<dyn DataChannel>>>>;

#[derive(Clone)]
pub struct ServerPeerHandler {
    pub uid: String,
    pub db: Store,
    pub channels: LiveChannels,
    pub signal_tx: mpsc::Sender<ServerFrame>,
}

#[async_trait]
impl PeerConnectionEventHandler for ServerPeerHandler {
    async fn on_ice_candidate(&self, event: RTCPeerConnectionIceEvent) {
        if let Ok(candidate) = event.candidate.to_json() {
            let candidate_str = &candidate.candidate;
            let cand_type = if candidate_str.contains("typ srflx") {
                "srflx (Google STUN)"
            } else if candidate_str.contains("typ host") {
                "host"
            } else if candidate_str.contains("typ relay") {
                "relay"
            } else {
                "unknown"
            };
            tracing::info!(user_id = %self.uid, candidate_type = %cand_type, "server gathered ICE candidate");
            let _ = self.signal_tx.send(ServerFrame::IceCandidate {
                candidate: serde_json::to_value(candidate).unwrap_or(json!({})),
            }).await;
        }
    }

    async fn on_data_channel(&self, channel: Arc<dyn DataChannel>) {
        let uid = self.uid.clone();
        let db = self.db.clone();
        let channels = self.channels.clone();
        tokio::spawn(async move {
            loop {
                let poll_result = tokio::time::timeout(std::time::Duration::from_secs(35), channel.poll()).await;
                let event = match poll_result {
                    Ok(Some(ev)) => ev,
                    Ok(None) => break,
                    Err(_) => {
                        tracing::info!(user_id = %uid, "client DataChannel inactive for 35s, closing session");
                        break;
                    }
                };
                match event {
                    DataChannelEvent::OnOpen => {
                        let previous = channels.lock().await.insert(uid.clone(), channel.clone());
                        if let Some(previous) = previous {
                            let _ = previous.close().await;
                        }
                        tracing::info!(user_id = %uid, "client DataChannel opened");
                        broadcast_presence(&db, &channels, &uid, true).await;

                        // Immediately inform this user about all currently connected users
                        let other_online: Vec<String> = {
                            let connected = channels.lock().await;
                            connected.keys().filter(|other_uid| *other_uid != &uid).cloned().collect()
                        };
                        for contact_uid in other_online {
                            let frame = DataChannelServerFrame::PresenceUpdate {
                                uid: contact_uid,
                                online: true,
                            };
                            if let Ok(text) = serde_json::to_string(&frame) {
                                let _ = channel.send_text(&text).await;
                            }
                        }
                    }
                    DataChannelEvent::OnMessage(message) => {
                        if message.data.len() > 16 * 1024 {
                            send_dc_error(&channel, "FRAME_TOO_LARGE", "data-channel frame exceeds 16 KiB").await;
                            continue;
                        }
                        let parsed = serde_json::from_slice::<DataChannelClientFrame>(&message.data);
                        let Ok(frame) = parsed else {
                            send_dc_error(&channel, "BAD_FRAME", "invalid data-channel frame").await;
                            continue;
                        };
                        match frame {
                            DataChannelClientFrame::SendMessage {
                                message_id,
                                conversation_id,
                                ciphertext_b64,
                                created_at: _,
                            } => {
                                if ciphertext_b64.is_empty() || ciphertext_b64.len() > 16 * 1024 {
                                    send_dc_error(&channel, "INVALID_CIPHERTEXT", "ciphertext envelope is empty or too large").await;
                                    continue;
                                }
                                let ciphertext = match STANDARD.decode(&ciphertext_b64) {
                                    Ok(b) if !b.is_empty() => b,
                                    _ => {
                                        send_dc_error(&channel, "BAD_CIPHERTEXT", "ciphertext is not valid base64").await;
                                        continue;
                                    }
                                };

                                // Protocol check: Signal Protocol V3 requires min_version <= 3 and max_version >= 3.
                                // Standard pure V3 evaluates to 0x33 ((3 << 4) | 3).
                                let version_byte = ciphertext[0];
                                let min_version = version_byte & 0x0f;
                                let max_version = version_byte >> 4;
                                if min_version > 3 || max_version < 3 {
                                    send_dc_error(
                                        &channel,
                                        "E2EE_NOT_CONFIGURED",
                                        "message relay requires a valid Signal Protocol V3 ciphertext envelope",
                                    ).await;
                                    continue;
                                }

                                match db.save_ciphertext(&message_id, &conversation_id, &uid, &ciphertext).await {
                                    Ok((recipient_uid, is_new)) => {
                                        let saved_ack = DataChannelServerFrame::SavedAck { message_id: message_id.clone() };
                                        if let Ok(text) = serde_json::to_string(&saved_ack) {
                                            let _ = channel.send_text(&text).await;
                                        }

                                        if is_new {
                                            let msg = crate::protocol::MessageEnvelope {
                                                message_id: message_id.clone(),
                                                conversation_id: conversation_id.clone(),
                                                sender_uid: uid.clone(),
                                                ciphertext_b64: ciphertext_b64.clone(),
                                                created_at: crate::db::now_epoch_string(),
                                                status: "SAVED".to_string(),
                                            };
                                            let frame = DataChannelServerFrame::NewMessage { message: msg };
                                            send_to_user(&channels, &recipient_uid, &frame).await;
                                        }
                                    }
                                    Err(err) => {
                                        tracing::warn!(error = %err, "save_ciphertext failed");
                                        send_dc_error(&channel, "SAVE_FAILED", &err.to_string()).await;
                                    }
                                }
                            }
                            DataChannelClientFrame::DeliveredAck { message_id } => {
                                match db.mark_delivered(&message_id, &uid).await {
                                    Ok(Some(sender_uid)) => {
                                        let ack = DataChannelServerFrame::DeliveredAck { message_id };
                                        send_to_user(&channels, &sender_uid, &ack).await;
                                    }
                                    Ok(None) => {}
                                    Err(err) => tracing::warn!(error = %err, "failed to record delivered receipt"),
                                }
                            }
                            DataChannelClientFrame::SeenAck { message_id } => {
                                match db.mark_seen(&message_id, &uid).await {
                                    Ok(Some(sender_uid)) => {
                                        let ack = DataChannelServerFrame::SeenAck { message_id };
                                        send_to_user(&channels, &sender_uid, &ack).await;
                                    }
                                    Ok(None) => {}
                                    Err(err) => tracing::warn!(error = %err, "failed to record seen receipt"),
                                }
                            }
                            DataChannelClientFrame::Ping => {
                                if let Ok(text) = serde_json::to_string(&DataChannelServerFrame::Pong) {
                                    let _ = channel.send_text(&text).await;
                                }
                            }
                            DataChannelClientFrame::PresenceOffline => {
                                tracing::info!(user_id = %uid, "client explicitly reported offline");
                                break;
                            }
                        }
                    }
                    DataChannelEvent::OnClose => break,
                    _ => {}
                }
            }
            let mut guard = channels.lock().await;
            let removed = if guard.get(&uid).is_some_and(|existing| Arc::ptr_eq(existing, &channel)) {
                guard.remove(&uid);
                true
            } else {
                false
            };
            drop(guard);
            if removed {
                broadcast_presence(&db, &channels, &uid, false).await;
            }
            tracing::info!(user_id = %uid, "client DataChannel closed");
        });
    }
}

async fn deliver_one(db: &Store, channels: &LiveChannels, recipient_uid: &str, message_id: &str) {
    let Some(receiver) = channels.lock().await.get(recipient_uid).cloned() else { return; };
    let pending = match db.pending_deliveries(recipient_uid, 100).await {
        Ok(items) => items,
        Err(err) => { tracing::warn!(error = %err, "could not load pending deliveries"); return; }
    };
    for item in pending.into_iter().filter(|item| item.message.message_id == message_id) {
        let claimed = match db.claim_delivery_attempt(message_id, recipient_uid).await {
            Ok(value) => value,
            Err(err) => { tracing::warn!(error = %err, "could not claim outbox event"); false }
        };
        if !claimed { continue; }
        let frame = DataChannelServerFrame::NewMessage { message: item.message.clone() };
        if let Ok(text) = serde_json::to_string(&frame) {
            let _ = receiver.send_text(&text).await;
        }
    }
}

/// Polls only currently connected recipients. The database outbox remains the source of truth;
/// a missed ACK causes capped exponential-backoff retries after the channel reconnects.
pub async fn run_delivery_worker(db: Store, channels: LiveChannels) {
    loop {
        let recipients: Vec<String> = channels.lock().await.keys().cloned().collect();
        for uid in recipients {
            let channel = channels.lock().await.get(&uid).cloned();
            let Some(channel) = channel else { continue; };
            let pending = match db.pending_deliveries(&uid, 100).await {
                Ok(items) => items,
                Err(err) => {
                    tracing::warn!(user_id = %uid, error = %err, "outbox polling failed");
                    continue;
                }
            };
            for item in pending {
                let claimed = match db.claim_delivery_attempt(&item.message.message_id, &uid).await {
                    Ok(value) => value,
                    Err(err) => { tracing::warn!(message_id = %item.message.message_id, error = %err, "outbox claim failed"); false }
                };
                if !claimed { continue; }
                let frame = DataChannelServerFrame::NewMessage { message: item.message.clone() };
                let Ok(text) = serde_json::to_string(&frame) else { continue; };
                if channel.send_text(&text).await.is_err() { break; }
            }
        }
        sleep(Duration::from_secs(1)).await;
    }
}

pub async fn broadcast_presence(_db: &Store, channels: &LiveChannels, changed_uid: &str, online: bool) {
    let frame = DataChannelServerFrame::PresenceUpdate {
        uid: changed_uid.to_owned(),
        online,
    };
    let Ok(text) = serde_json::to_string(&frame) else { return; };
    let recipients: Vec<Arc<dyn DataChannel>> = {
        let connected = channels.lock().await;
        connected.iter().filter(|(uid, _)| *uid != changed_uid).map(|(_, channel)| Arc::clone(channel)).collect()
    };
    for channel in recipients {
        if let Err(err) = channel.send_text(&text).await {
            tracing::debug!(error = %err, "presence update could not be sent");
        }
    }
}

pub async fn send_to_user(channels: &LiveChannels, uid: &str, frame: &DataChannelServerFrame) {
    let Some(channel) = channels.lock().await.get(uid).cloned() else { return; };
    if let Ok(text) = serde_json::to_string(frame) { let _ = channel.send_text(&text).await; }
}

async fn send_dc_error(channel: &Arc<dyn DataChannel>, code: &str, message: &str) {
    let frame = DataChannelServerFrame::Error { code: code.to_owned(), message: message.chars().take(240).collect() };
    if let Ok(text) = serde_json::to_string(&frame) { let _ = channel.send_text(&text).await; }
}

pub async fn build_answerer(
    uid: String,
    db: Store,
    channels: LiveChannels,
    signal_tx: mpsc::Sender<ServerFrame>,
    offer_sdp: String,
    ice_urls: Vec<String>,
) -> Result<(Arc<dyn PeerConnection>, String)> {
    let handler = ServerPeerHandler { uid, db, channels, signal_tx };
    // Google STUN only: filter out any non-STUN or TURN URLs.
    let stun_urls: Vec<String> = ice_urls
        .into_iter()
        .filter(|url| url.starts_with("stun:"))
        .collect();
    let effective_urls = if stun_urls.is_empty() {
        vec!["stun:stun.l.google.com:19302".to_string()]
    } else {
        stun_urls
    };
    let ice_servers: Vec<RTCIceServer> = effective_urls
        .into_iter()
        .map(|url| RTCIceServer { urls: vec![url], ..Default::default() })
        .collect();
    let config = RTCConfigurationBuilder::default().with_ice_servers(ice_servers).build();
    let peer = PeerConnectionBuilder::new()
        .with_configuration(config)
        .with_handler(Arc::new(handler))
        .with_udp_addrs(vec!["0.0.0.0:0"])
        .with_data_channel_send_buffer_limit(256 * 1024)
        .build().await.context("build WebRTC peer")?;
    let offer = RTCSessionDescription::offer(offer_sdp)?;
    peer.set_remote_description(offer).await?;
    let answer = peer.create_answer(None).await?;
    peer.set_local_description(answer).await?;
    let local = peer.local_description().await.context("local SDP unavailable")?;
    Ok((Arc::new(peer), local.sdp))
}

