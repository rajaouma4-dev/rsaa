mod db;
mod protocol;
mod webrtc_peer;

use anyhow::{anyhow, Context, Result};
use db::Store;
use protocol::{ClientFrame, DataChannelServerFrame, ServerFrame};
use rustls::pki_types::{CertificateDer, PrivateKeyDer};
use std::{collections::{HashMap, VecDeque}, env, fs::File, io::BufReader, net::IpAddr, sync::Arc};
use tokio::{
    io::{AsyncBufRead, AsyncBufReadExt, AsyncRead, AsyncWriteExt, BufReader as TokioBufReader},
    net::TcpListener,
    sync::{mpsc, Mutex, Semaphore},
    time::{timeout, Duration, Instant},
};
use tokio_rustls::TlsAcceptor;
use webrtc::peer_connection::PeerConnection;
use webrtc_peer::{build_answerer, run_delivery_worker, send_to_user, LiveChannels};

const MAX_SIGNAL_FRAME_BYTES: usize = 64 * 1024;

#[derive(Clone, Default)]
struct AuthRateLimiter {
    attempts: Arc<Mutex<HashMap<IpAddr, VecDeque<Instant>>>>,
}

impl AuthRateLimiter {
    async fn allow(&self, ip: IpAddr) -> bool {
        let now = Instant::now();
        let mut all = self.attempts.lock().await;
        if all.len() > 10_000 {
            all.retain(|_, entries| entries.back().is_some_and(|last| now.duration_since(*last) < Duration::from_secs(60)));
        }
        let entries = all.entry(ip).or_default();
        while entries.front().is_some_and(|at| now.duration_since(*at) >= Duration::from_secs(60)) {
            entries.pop_front();
        }
        if entries.len() >= 10 { return false; }
        entries.push_back(now);
        true
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt().with_env_filter(
        env::var("RUST_LOG").unwrap_or_else(|_| "nexa_messenger_server=info,webrtc=warn".into()),
    ).init();

    let url = env::var("TURSO_DATABASE_URL").context("TURSO_DATABASE_URL missing")?;
    let token = env::var("TURSO_AUTH_TOKEN").context("TURSO_AUTH_TOKEN missing")?;
    let store = Store::connect(&url, &token).await?;
    store.migrate().await?;

    let cert_path = env::var("TLS_CERT_PATH").unwrap_or_else(|_| "./certs/server.crt".into());
    let key_path = env::var("TLS_KEY_PATH").unwrap_or_else(|_| "./certs/server.key".into());
    let tls = build_tls_acceptor(&cert_path, &key_path)?;
    let bind = env::var("SIGNAL_BIND").unwrap_or_else(|_| "0.0.0.0:7443".into());
    let listener = TcpListener::bind(&bind).await?;
    let channels: LiveChannels = Arc::new(tokio::sync::Mutex::new(std::collections::HashMap::new()));
    let auth_limiter = AuthRateLimiter::default();
    let max_connections = env::var("MAX_SIGNAL_CONNECTIONS").ok().and_then(|value| value.parse::<usize>().ok()).unwrap_or(500).clamp(10, 10_000);
    let connection_slots = Arc::new(Semaphore::new(max_connections));
    tokio::spawn(run_delivery_worker(store.clone(), channels.clone()));
    let ice_urls: Vec<String> = env::var("ICE_URLS")
        .unwrap_or_else(|_| "stun:stun.l.google.com:19302".into())
        .split(',').map(str::trim).filter(|s| !s.is_empty()).map(str::to_owned).collect();

    tracing::info!(%bind, "Nexa TLS signaling listener started (raw TLS/TCP, no HTTP)");
    loop {
        let (stream, peer_addr) = listener.accept().await?;
        let permit = match connection_slots.clone().acquire_owned().await {
            Ok(permit) => permit,
            Err(_) => return Err(anyhow!("connection semaphore closed")),
        };
        let _ = stream.set_nodelay(true);
        let acceptor = tls.clone();
        let store = store.clone();
        let channels = channels.clone();
        let ice_urls = ice_urls.clone();
        let auth_limiter = auth_limiter.clone();
        let client_ip = peer_addr.ip();
        tokio::spawn(async move {
            let _connection_permit = permit;
            match timeout(Duration::from_secs(10), acceptor.accept(stream)).await {
                Ok(Ok(stream)) => {
                    if let Err(err) = handle_client(stream, store, channels, ice_urls, auth_limiter, client_ip).await {
                        tracing::warn!(%peer_addr, error = %err, "signaling connection ended");
                    }
                }
                Ok(Err(err)) => tracing::warn!(%peer_addr, error = %err, "TLS handshake failed"),
                Err(_) => tracing::warn!(%peer_addr, "TLS handshake timed out"),
            }
        });
    }
}

fn build_tls_acceptor(cert_path: &str, key_path: &str) -> Result<TlsAcceptor> {
    let cert_file = File::open(cert_path).with_context(|| format!("open TLS cert {cert_path}"))?;
    let key_file = File::open(key_path).with_context(|| format!("open TLS key {key_path}"))?;
    let certs: Vec<CertificateDer<'static>> = rustls_pemfile::certs(&mut BufReader::new(cert_file))
        .collect::<std::result::Result<_, _>>()?;
    anyhow::ensure!(!certs.is_empty(), "TLS certificate file contains no certificates");
    let key: PrivateKeyDer<'static> = rustls_pemfile::private_key(&mut BufReader::new(key_file))?
        .context("TLS private key file contains no private key")?;
    // Signaling is intentionally TLS 1.3 only. WebRTC's separate DTLS transport is
    // negotiated by the WebRTC implementation and is not affected by this setting.
    let provider = Arc::new(rustls::crypto::ring::default_provider());
    let config = rustls::ServerConfig::builder_with_provider(provider)
        .with_protocol_versions(&[&rustls::version::TLS13])?
        .with_no_client_auth()
        .with_single_cert(certs, key)
        .context("certificate and private key do not match")?;
    Ok(TlsAcceptor::from(Arc::new(config)))
}

async fn handle_client<S>(stream: S, store: Store, channels: LiveChannels, ice_urls: Vec<String>, auth_limiter: AuthRateLimiter, client_ip: IpAddr) -> Result<()>
where
    S: AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'static,
{
    let (reader, mut writer) = tokio::io::split(stream);
    let mut reader = TokioBufReader::with_capacity(8 * 1024, reader);
    let (signal_tx, mut signal_rx) = mpsc::channel::<ServerFrame>(128);
    tokio::spawn(async move {
        while let Some(frame) = signal_rx.recv().await {
            let Ok(mut bytes) = serde_json::to_vec(&frame) else { continue; };
            bytes.push(b'\n');
            if writer.write_all(&bytes).await.is_err() { break; }
        }
    });

    let mut current_user: Option<protocol::UserSummary> = None;
    let mut current_session_token: Option<String> = None;
    let mut current_peer: Option<Arc<dyn PeerConnection>> = None;
    let mut last_session_check = Instant::now();

    while let Some(line) = read_bounded_line(&mut reader, MAX_SIGNAL_FRAME_BYTES).await? {
        if line.trim().is_empty() { continue; }
        let frame: ClientFrame = match serde_json::from_str(&line) {
            Ok(frame) => frame,
            Err(_) => {
                send_error(&signal_tx, "BAD_FRAME", "invalid signaling frame").await?;
                continue;
            }
        };

        // A long-lived TLS socket must not outlive a revoked or expired session forever.
        // Revalidate once per minute to bound the revocation window without querying Turso
        // for every ICE candidate or application frame.
        let mut session_expired = false;
        if let Some(token) = current_session_token.clone() {
            if last_session_check.elapsed() >= Duration::from_secs(60) {
                last_session_check = Instant::now();
                match store.authenticate(&token).await {
                    Ok(user) => current_user = Some(user),
                    Err(_) => {
                        current_user = None;
                        current_session_token = None;
                        if let Some(peer) = current_peer.take() { let _ = peer.close().await; }
                        session_expired = true;
                    }
                }
            }
        }
        if session_expired {
            send_error(&signal_tx, "SESSION_EXPIRED", "session expired or revoked; sign in again").await?;
            continue;
        }

        match frame {
            ClientFrame::Register { username, display_name, password } => {
                if current_user.is_some() {
                    send_error(&signal_tx, "ALREADY_AUTHENTICATED", "logout before changing account").await?;
                    continue;
                }
                if !auth_limiter.allow(client_ip).await {
                    send_error(&signal_tx, "RATE_LIMITED", "too many login attempts; try again in one minute").await?;
                    continue;
                }
                match store.register(&username, &display_name, &password).await {
                    Ok((user, token)) => {
                        current_user = Some(user.clone());
                        current_session_token = Some(token.clone());
                        last_session_check = Instant::now();
                        send_auth_ok(&signal_tx, user, token).await?;
                    }
                    Err(err) => send_error(&signal_tx, "REGISTER_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::Login { username, password } => {
                if current_user.is_some() {
                    send_error(&signal_tx, "ALREADY_AUTHENTICATED", "logout before changing account").await?;
                    continue;
                }
                if !auth_limiter.allow(client_ip).await {
                    send_error(&signal_tx, "RATE_LIMITED", "too many login attempts; try again in one minute").await?;
                    continue;
                }
                match store.login(&username, &password).await {
                    Ok((user, token)) => {
                        current_user = Some(user.clone());
                        current_session_token = Some(token.clone());
                        last_session_check = Instant::now();
                        send_auth_ok(&signal_tx, user, token).await?;
                    }
                    Err(err) => send_error(&signal_tx, "LOGIN_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::Resume { token } => {
                if current_user.is_some() {
                    send_error(&signal_tx, "ALREADY_AUTHENTICATED", "logout before changing account").await?;
                    continue;
                }
                match store.authenticate(&token).await {
                    Ok(user) => {
                        current_user = Some(user.clone());
                        current_session_token = Some(token.clone());
                        last_session_check = Instant::now();
                        send_auth_ok(&signal_tx, user, token).await?;
                    }
                    Err(err) => send_error(&signal_tx, "AUTH_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::Logout => {
                if let Some(token) = current_session_token.as_ref() {
                    if let Err(err) = store.revoke_session(token).await {
                        tracing::error!(error = %err, "session revocation failed");
                        send_error(&signal_tx, "LOGOUT_FAILED", "could not revoke session; try again").await?;
                        continue;
                    }
                }
                current_session_token = None;
                current_user = None;
                if let Some(peer) = current_peer.take() { let _ = peer.close().await; }
                signal_tx.send(ServerFrame::LoggedOut).await.map_err(|_| anyhow!("signaling writer closed"))?;
            }
            ClientFrame::SearchUsers { query } => {
                let Some(user) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login required").await?;
                    continue;
                };
                match store.search_users(&user.uid, &query).await {
                    Ok(mut users) => {
                        let connected = channels.lock().await;
                        for item in &mut users {
                            item.online = connected.contains_key(&item.uid);
                        }
                        drop(connected);
                        signal_tx.send(ServerFrame::Users { users }).await.map_err(|_| anyhow!("signaling writer closed"))?;
                    }
                    Err(err) => send_error(&signal_tx, "SEARCH_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::ListConversations => {
                let Some(user) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login required").await?;
                    continue;
                };
                match store.list_conversations(&user.uid, 100).await {
                    Ok(mut conversations) => {
                        let connected = channels.lock().await;
                        for item in &mut conversations { item.user.online = connected.contains_key(&item.user.uid); }
                        drop(connected);
                        signal_tx.send(ServerFrame::Conversations { conversations }).await.map_err(|_| anyhow!("signaling writer closed"))?;
                    }
                    Err(err) => send_error(&signal_tx, "CONVERSATIONS_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::UpdateProfile { display_name, about } => {
                let Some(user) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login required").await?;
                    continue;
                };
                match store.update_profile(&user.uid, &display_name, &about).await {
                    Ok(updated) => {
                        current_user = Some(updated.clone());
                        signal_tx.send(ServerFrame::ProfileUpdated { user: updated }).await.map_err(|_| anyhow!("signaling writer closed"))?;
                    }
                    Err(err) => send_error(&signal_tx, "PROFILE_UPDATE_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::CreateConversation { other_uid } => {
                let Some(user) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login required").await?;
                    continue;
                };
                match store.create_or_get_conversation(&user.uid, &other_uid).await {
                    Ok(()) => {
                        let result = async {
                            let conversation_id = store.get_conversation_id(&user.uid, &other_uid).await?;
                            let mut other = store.get_user(&other_uid).await?;
                            other.online = channels.lock().await.contains_key(&other_uid);
                            Ok::<_, anyhow::Error>((conversation_id, other))
                        }.await;
                        match result {
                            Ok((conversation_id, other)) => {
                                let notification = DataChannelServerFrame::NewConversation {
                                    conversation_id: conversation_id.clone(),
                                    user: user.clone(),
                                };
                                send_to_user(&channels, &other_uid, &notification).await;
                                crate::webrtc_peer::broadcast_presence(&store, &channels, &user.uid, true).await;
                                signal_tx.send(ServerFrame::Conversation { conversation_id, user: other }).await.map_err(|_| anyhow!("signaling writer closed"))?;
                            }
                            Err(err) => send_error(&signal_tx, "CONVERSATION_FAILED", &safe_error(&err)).await?,
                        }
                    }
                    Err(err) => send_error(&signal_tx, "CONVERSATION_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::ConversationHistory { conversation_id, before } => {
                let Some(user) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login required").await?;
                    continue;
                };
                match store.history(&user.uid, &conversation_id, before.as_deref(), 100).await {
                    Ok(messages) => {
                        signal_tx.send(ServerFrame::History { conversation_id, messages }).await.map_err(|_| anyhow!("signaling writer closed"))?;
                    }
                    Err(err) => send_error(&signal_tx, "HISTORY_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::Offer { sdp } => {
                let Some(user) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login before WebRTC offer").await?;
                    continue;
                };
                if let Some(old_peer) = current_peer.take() { let _ = old_peer.close().await; }
                match build_answerer(user.uid.clone(), store.clone(), channels.clone(), signal_tx.clone(), sdp, ice_urls.clone()).await {
                    Ok((peer, answer_sdp)) => {
                        current_peer = Some(peer);
                        signal_tx.send(ServerFrame::Answer { sdp: answer_sdp }).await.map_err(|_| anyhow!("signaling writer closed"))?;
                    }
                    Err(err) => send_error(&signal_tx, "WEBRTC_NEGOTIATION_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::IceCandidate { candidate } => {
                if let Some(peer) = current_peer.as_ref() {
                    match serde_json::from_value::<webrtc::peer_connection::RTCIceCandidateInit>(candidate) {
                        Ok(candidate) => {
                            if let Err(err) = peer.add_ice_candidate(candidate).await {
                                send_error(&signal_tx, "ICE_CANDIDATE_REJECTED", &safe_error(&err)).await?;
                            }
                        }
                        Err(err) => send_error(&signal_tx, "BAD_ICE_CANDIDATE", &safe_error(&err)).await?,
                    }
                } else {
                    send_error(&signal_tx, "PEER_NOT_READY", "send SDP offer before ICE candidates").await?;
                }
            }
            ClientFrame::PublishPrekeys { bundle } => {
                let Some(user) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login required").await?;
                    continue;
                };
                let bundle_str = bundle.to_string();
                match store.save_prekey_bundle(&user.uid, &bundle_str).await {
                    Ok(()) => {
                        signal_tx.send(ServerFrame::PrekeysPublished).await.map_err(|_| anyhow!("signaling writer closed"))?;
                    }
                    Err(err) => send_error(&signal_tx, "PREKEY_SAVE_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::GetPrekeyBundle { uid } => {
                let Some(_) = current_user.as_ref() else {
                    send_error(&signal_tx, "AUTH_REQUIRED", "login required").await?;
                    continue;
                };
                match store.get_prekey_bundle(&uid).await {
                    Ok(Some(bundle_str)) => {
                        let bundle: serde_json::Value = serde_json::from_str(&bundle_str).unwrap_or(serde_json::Value::Null);
                        signal_tx.send(ServerFrame::PrekeyBundle { uid, bundle }).await.map_err(|_| anyhow!("signaling writer closed"))?;
                    }
                    Ok(None) => send_error(&signal_tx, "PREKEY_NOT_FOUND", "user has not published prekeys").await?,
                    Err(err) => send_error(&signal_tx, "PREKEY_FETCH_FAILED", &safe_error(&err)).await?,
                }
            }
            ClientFrame::Ping => {
                signal_tx.send(ServerFrame::Pong).await.map_err(|_| anyhow!("signaling writer closed"))?;
            }
        }
    }

    if let Some(peer) = current_peer { let _ = peer.close().await; }
    if let Some(user) = current_user {
        channels.lock().await.remove(&user.uid);
        crate::webrtc_peer::broadcast_presence(&store, &channels, &user.uid, false).await;
    }
    Ok(())
}

async fn read_bounded_line<R: AsyncBufRead + Unpin>(reader: &mut R, max: usize) -> Result<Option<String>> {
    let mut bytes = Vec::with_capacity(1024);
    loop {
        let available = reader.fill_buf().await?;
        if available.is_empty() {
            if bytes.is_empty() { return Ok(None); }
            break;
        }
        let newline = available.iter().position(|byte| *byte == b'\n');
        let consumed = newline.map_or(available.len(), |index| index + 1);
        let payload_len = newline.map_or(consumed, |index| index);
        anyhow::ensure!(bytes.len() + payload_len <= max, "signaling frame exceeds {max} bytes");
        bytes.extend_from_slice(&available[..payload_len]);
        reader.consume(consumed);
        if newline.is_some() { break; }
    }
    Ok(Some(String::from_utf8(bytes).context("signaling frame is not UTF-8")?))
}

async fn send_auth_ok(tx: &mpsc::Sender<ServerFrame>, user: protocol::UserSummary, token: String) -> Result<()> {
    tx.send(ServerFrame::AuthOk {
        uid: user.uid,
        username: user.username,
        display_name: user.display_name,
        about: user.about,
        token,
    }).await.map_err(|_| anyhow!("signaling writer closed"))
}

async fn send_error(tx: &mpsc::Sender<ServerFrame>, code: &str, message: &str) -> Result<()> {
    tx.send(ServerFrame::Error {
        code: code.to_owned(),
        message: message.chars().take(240).collect(),
    }).await.map_err(|_| anyhow!("signaling writer closed"))
}

fn safe_error<E: std::fmt::Display>(err: &E) -> String {
    // Avoid exposing SQL, filesystem and cryptographic internals to untrusted clients.
    let message = err.to_string();
    if message.contains("username") || message.contains("password") || message.contains("characters") || message.contains("conversation") || message.contains("user not found") {
        message.chars().take(200).collect()
    } else {
        "request could not be completed".to_owned()
    }
}

#[cfg(test)]
mod tests {
    use super::read_bounded_line;
    use tokio::io::BufReader;

    #[tokio::test]
    async fn bounded_reader_handles_multiple_lines_and_eof() {
        let input = b"one\ntwo\n";
        let mut reader = BufReader::new(&input[..]);
        assert_eq!(read_bounded_line(&mut reader, 8).await.unwrap().as_deref(), Some("one"));
        assert_eq!(read_bounded_line(&mut reader, 8).await.unwrap().as_deref(), Some("two"));
        assert_eq!(read_bounded_line(&mut reader, 8).await.unwrap(), None);
    }

    #[tokio::test]
    async fn bounded_reader_rejects_oversized_frame() {
        let input = b"12345\n";
        let mut reader = BufReader::new(&input[..]);
        assert!(read_bounded_line(&mut reader, 4).await.is_err());
    }
}
