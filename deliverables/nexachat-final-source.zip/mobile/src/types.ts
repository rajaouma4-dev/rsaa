export type User = {id: string; username: string; name: string; online: boolean; about?: string; lastActive?: number};
export type ChatMessage = {id: string; from: 'me' | 'them'; text: string; time: string; timestamp?: number; status: 'sent' | 'saved' | 'delivered' | 'seen'};
export type Chat = {id: string; user: User; preview: string; time: string; timestamp?: number; unread: number; messages: ChatMessage[]};
