import AsyncStorage from '@react-native-async-storage/async-storage';
import {ChatMessage} from '../types';
import {getMessageTimestamp} from '../utils/time';

const MSG_PREFIX = 'nexa.chat.messages.v2.';

export async function getLocalMessages(conversationId: string): Promise<ChatMessage[]> {
  try {
    const raw = await AsyncStorage.getItem(MSG_PREFIX + conversationId);
    if (!raw) return [];
    const list = JSON.parse(raw) as ChatMessage[];
    return list.sort((a, b) => getMessageTimestamp(a) - getMessageTimestamp(b));
  } catch {
    return [];
  }
}

export async function saveLocalMessages(conversationId: string, messages: ChatMessage[]): Promise<void> {
  try {
    // Keep up to 500 recent messages per conversation locally, always in chronological order
    const sorted = [...messages].sort((a, b) => getMessageTimestamp(a) - getMessageTimestamp(b));
    const trimmed = sorted.slice(-500);
    await AsyncStorage.setItem(MSG_PREFIX + conversationId, JSON.stringify(trimmed));
  } catch (err) {
    console.warn('Failed to save local messages:', err);
  }
}

export async function appendLocalMessage(conversationId: string, message: ChatMessage): Promise<ChatMessage[]> {
  try {
    const current = await getLocalMessages(conversationId);
    let updated: ChatMessage[];
    if (current.some(m => m.id === message.id)) {
      updated = current.map(m => m.id === message.id ? {...m, ...message} : m);
    } else {
      updated = [...current, message];
    }
    updated.sort((a, b) => getMessageTimestamp(a) - getMessageTimestamp(b));
    await saveLocalMessages(conversationId, updated);
    return updated;
  } catch {
    return [message];
  }
}

export async function updateLocalMessageStatus(
  conversationId: string,
  messageId: string,
  status: 'saved' | 'delivered' | 'seen',
): Promise<void> {
  try {
    const current = await getLocalMessages(conversationId);
    let changed = false;
    const updated = current.map(m => {
      if (m.id === messageId && m.status !== status) {
        changed = true;
        return {...m, status};
      }
      return m;
    });
    if (changed) {
      await saveLocalMessages(conversationId, updated);
    }
  } catch {}
}

export async function getConversationPreview(conversationId: string): Promise<string | null> {
  try {
    const msgs = await getLocalMessages(conversationId);
    if (msgs.length > 0) {
      return msgs[msgs.length - 1].text;
    }
    return null;
  } catch {
    return null;
  }
}
