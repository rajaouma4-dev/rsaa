export const APP_CONFIG = {
  // Live mode is strictly enforced and fail-closed. Unauthenticated demo bypass is disabled.
  DEMO_MODE: false,
  // Production signaling host: public domain only, no hardcoded localhost or private LAN IP.
  SIGNALING_HOST: 'chat.YOUR_DOMAIN.com',
  // Candidate hosts for fallback during local development/testing
  CANDIDATE_HOSTS: ['chat.YOUR_DOMAIN.com', '10.109.201.244', '10.0.2.2'],
  SIGNALING_PORT: 7443,
  // Pin the SHA-256 fingerprint of the leaf TLS certificate. Add backup pins before rotation.
  TLS_CERT_SHA256_PINS: [
    '044db75f48cf4514638bdf7da3cc1162fbed36017b99c7a848f69de479000cc5',
  ],
  MAX_SIGNAL_FRAME_BYTES: 65_536,
  // Google's public STUN server ONLY for NAT discovery.
  ICE_SERVERS: [
    {
      urls: ['stun:stun.l.google.com:19302'],
    },
  ],
  ICE_TRANSPORT_POLICY: 'all' as const,
  APP_NAME: 'Nexa Chat',
};

export function updateSignalingHost(host: string) {
  const cleaned = host.trim().replace(/^https?:\/\//i, '').replace(/:\d+$/, '');
  if (cleaned) {
    APP_CONFIG.SIGNALING_HOST = cleaned;
    if (!APP_CONFIG.CANDIDATE_HOSTS.includes(cleaned)) {
      APP_CONFIG.CANDIDATE_HOSTS = [cleaned, ...APP_CONFIG.CANDIDATE_HOSTS];
    }
  }
}

export function isLiveConfigReady(): boolean {
  return !APP_CONFIG.DEMO_MODE &&
    Boolean(APP_CONFIG.SIGNALING_HOST) &&
    APP_CONFIG.SIGNALING_PORT > 0 &&
    APP_CONFIG.ICE_SERVERS.length === 1 &&
    APP_CONFIG.ICE_SERVERS[0].urls.length === 1 &&
    APP_CONFIG.ICE_SERVERS[0].urls[0] === 'stun:stun.l.google.com:19302' &&
    !('username' in (APP_CONFIG.ICE_SERVERS[0] as any)) &&
    !('credential' in (APP_CONFIG.ICE_SERVERS[0] as any));
}
