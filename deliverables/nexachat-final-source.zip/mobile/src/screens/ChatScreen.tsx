import React, {useEffect, useMemo, useRef, useState} from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
} from 'react-native';
import {Avatar} from '../components/Avatar';
import {Chat, ChatMessage} from '../types';
import {formatPresence, getMessageTimestamp} from '../utils/time';

function formatHeaderTime(timestamp?: number, fallbackTime?: string): string {
  if (!timestamp) return fallbackTime || '';
  const d = new Date(timestamp);
  const now = new Date();
  const isToday =
    d.getDate() === now.getDate() &&
    d.getMonth() === now.getMonth() &&
    d.getFullYear() === now.getFullYear();

  const timeStr = d.toLocaleTimeString([], {hour: 'numeric', minute: '2-digit'});
  if (isToday) return timeStr;

  const dateStr = d.toLocaleDateString([], {month: 'short', day: 'numeric'});
  return `${dateStr}, ${timeStr}`;
}

export function ChatScreen({
  chat,
  liveMode,
  rtcStatus,
  onBack,
  onSend,
}: {
  chat: Chat;
  liveMode: boolean;
  rtcStatus: string;
  onBack: () => void;
  onSend: (text: string) => void;
}) {
  const [text, setText] = useState('');
  const [, setTick] = useState(0);
  const list = useRef<FlatList<ChatMessage>>(null);

  // Live ticker to update relative presence time (e.g. Active 10s ago -> Active 1m ago)
  useEffect(() => {
    const timer = setInterval(() => {
      setTick(t => t + 1);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const sortedMessages = useMemo(() => {
    return [...chat.messages].sort((a, b) => {
      const timeA = getMessageTimestamp(a);
      const timeB = getMessageTimestamp(b);
      if (timeA !== timeB) return timeA - timeB;
      return a.id.localeCompare(b.id);
    });
  }, [chat.messages]);

  const send = () => {
    const value = text.trim();
    if (!value) return;
    onSend(value);
    setText('');
    setTimeout(() => {
      list.current?.scrollToEnd({animated: true});
    }, 60);
    setTimeout(() => {
      list.current?.scrollToEnd({animated: false});
    }, 220);
  };

  const renderMessage = ({item, index}: {item: ChatMessage; index: number}) => {
    const isMe = item.from === 'me';
    const prev = sortedMessages[index - 1];
    const next = sortedMessages[index + 1];

    const isFirstInGroup = !prev || prev.from !== item.from;
    const isLastInGroup = !next || next.from !== item.from;

    // Show date/time separator if first message or > 15 mins since prev
    const prevTime = prev?.timestamp || 0;
    const currTime = item.timestamp || 0;
    const showTimeDivider =
      index === 0 || (currTime > 0 && prevTime > 0 && currTime - prevTime > 15 * 60 * 1000);

    const messageTime = item.time || formatHeaderTime(item.timestamp);

    return (
      <View key={item.id} style={styles.messageWrapper}>
        {showTimeDivider ? (
          <View style={styles.timeDividerContainer}>
            <Text style={styles.timeDividerText}>
              {formatHeaderTime(item.timestamp, item.time)}
            </Text>
          </View>
        ) : null}

        {/* Facebook Messenger Style User Name above first message of cluster */}
        {!isMe && isFirstInGroup ? (
          <View style={styles.senderNameRow}>
            <Text style={styles.senderNameText}>{chat.user.name}</Text>
          </View>
        ) : null}

        <View
          style={[
            styles.messageRow,
            isMe ? styles.messageRowMe : styles.messageRowThem,
            {marginTop: isFirstInGroup ? 4 : 2},
          ]}>
          {/* Recipient avatar beside bottom message of group */}
          {!isMe ? (
            <View style={styles.themAvatarContainer}>
              {isLastInGroup ? (
                <Avatar name={chat.user.name} online={chat.user.online} size={28} />
              ) : (
                <View style={styles.themAvatarSpacer} />
              )}
            </View>
          ) : null}

          <View style={styles.bubbleContainer}>
            <View
              style={[
                styles.bubble,
                isMe ? styles.bubbleMe : styles.bubbleThem,
                isMe
                  ? {
                      borderTopRightRadius: isFirstInGroup ? 18 : 6,
                      borderBottomRightRadius: isLastInGroup ? 4 : 6,
                    }
                  : {
                      borderTopLeftRadius: isFirstInGroup ? 18 : 6,
                      borderBottomLeftRadius: isLastInGroup ? 4 : 6,
                    },
              ]}>
              <Text style={styles.messageText}>{item.text}</Text>
            </View>

            {/* Always visible timestamp & receipt directly underneath every bubble */}
            <View style={[styles.metaRow, isMe ? styles.metaRowMe : styles.metaRowThem]}>
              <Text style={styles.metaTime}>{messageTime}</Text>
              {isMe ? (
                <Text
                  style={[
                    styles.receiptText,
                    item.status === 'seen' && styles.receiptSeen,
                  ]}>
                  {item.status === 'seen'
                    ? ' · Seen'
                    : item.status === 'delivered'
                    ? ' · Delivered'
                    : ' · Sent'}
                </Text>
              ) : null}
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.screen}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={4}>
      {/* Facebook Messenger Style Header */}
      <View style={styles.header}>
        <Pressable onPress={onBack} hitSlop={10} style={styles.backBtn}>
          <Text style={styles.backArrow}>‹</Text>
        </Pressable>
        <Avatar name={chat.user.name} online={chat.user.online} size={42} />
        <View style={styles.headerInfo}>
          <Text numberOfLines={1} style={styles.headerName}>
            {chat.user.name}
          </Text>
          <Text
            style={[
              styles.headerPresence,
              chat.user.online ? styles.presenceOnline : styles.presenceOffline,
            ]}>
            {formatPresence(chat.user.online, chat.user.lastActive)}
          </Text>
        </View>
        <View style={styles.headerBadge}>
          <Text style={styles.badgeText}>
            {liveMode ? `E2EE · ${rtcStatus.toUpperCase()}` : 'DEMO'}
          </Text>
        </View>
      </View>

      {/* Message List with Smooth Auto-Scroll and generous bottom spacing */}
      <FlatList
        ref={list}
        data={sortedMessages}
        keyExtractor={m => m.id}
        contentContainerStyle={[styles.messagesContainer, {paddingBottom: 28}]}
        ListFooterComponent={<View style={{height: 14}} />}
        onContentSizeChange={() => list.current?.scrollToEnd({animated: false})}
        onLayout={() => list.current?.scrollToEnd({animated: false})}
        renderItem={renderMessage}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Avatar name={chat.user.name} online={chat.user.online} size={70} />
            <Text style={styles.emptyTitle}>{chat.user.name}</Text>
            <Text style={styles.emptySubtitle}>
              {liveMode
                ? 'Signal Protocol Double Ratchet E2EE · Messages are end-to-end encrypted.'
                : 'Send your first message to start conversation.'}
            </Text>
          </View>
        }
      />

      {/* Facebook Messenger Style Composer */}
      <View style={styles.composerContainer}>
        <View style={styles.inputPill}>
          <TextInput
            editable={true}
            value={text}
            onChangeText={setText}
            placeholder="Aa"
            placeholderTextColor="#8A8D91"
            style={styles.input}
            multiline
          />
        </View>
        <Pressable
          onPress={send}
          disabled={!text.trim()}
          style={[styles.sendBtn, !text.trim() && styles.sendBtnDisabled]}>
          <Text style={styles.sendIcon}>➤</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#18191A',
  },
  header: {
    height: 64,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#242526',
    borderBottomWidth: 1,
    borderBottomColor: '#393A3B',
    gap: 10,
  },
  backBtn: {
    width: 34,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backArrow: {
    color: '#0084FF',
    fontSize: 36,
    lineHeight: 40,
    fontWeight: '300',
  },
  headerInfo: {
    flex: 1,
    justifyContent: 'center',
  },
  headerName: {
    color: '#E4E6EB',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  headerPresence: {
    fontSize: 12,
    marginTop: 2,
    fontWeight: '500',
  },
  presenceOnline: {
    color: '#31A24C',
  },
  presenceOffline: {
    color: '#B0B3B8',
  },
  headerBadge: {
    backgroundColor: '#3A3B3C',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  badgeText: {
    color: '#B0B3B8',
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  messagesContainer: {
    paddingHorizontal: 10,
    paddingVertical: 12,
    flexGrow: 1,
  },
  messageWrapper: {
    width: '100%',
  },
  timeDividerContainer: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  timeDividerText: {
    color: '#B0B3B8',
    fontSize: 11,
    fontWeight: '600',
  },
  senderNameRow: {
    marginLeft: 40,
    marginTop: 8,
    marginBottom: 2,
  },
  senderNameText: {
    color: '#B0B3B8',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: -0.1,
  },
  messageRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    width: '100%',
  },
  messageRowMe: {
    justifyContent: 'flex-end',
  },
  messageRowThem: {
    justifyContent: 'flex-start',
  },
  themAvatarContainer: {
    width: 32,
    alignItems: 'center',
    marginRight: 6,
    marginBottom: 16,
  },
  themAvatarSpacer: {
    width: 28,
    height: 28,
  },
  bubbleContainer: {
    maxWidth: '75%',
  },
  bubble: {
    paddingHorizontal: 13,
    paddingVertical: 9,
    borderRadius: 18,
  },
  bubbleMe: {
    backgroundColor: '#0084FF',
    borderTopLeftRadius: 18,
    borderBottomLeftRadius: 18,
  },
  bubbleThem: {
    backgroundColor: '#3A3B3C',
    borderTopRightRadius: 18,
    borderBottomRightRadius: 18,
  },
  messageText: {
    color: '#FFFFFF',
    fontSize: 15,
    lineHeight: 20,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 3,
    marginBottom: 4,
  },
  metaRowMe: {
    justifyContent: 'flex-end',
    marginRight: 4,
  },
  metaRowThem: {
    justifyContent: 'flex-start',
    marginLeft: 4,
  },
  metaTime: {
    color: '#8A8D91',
    fontSize: 10,
    fontWeight: '500',
  },
  receiptText: {
    color: '#8A8D91',
    fontSize: 10,
    fontWeight: '500',
  },
  receiptSeen: {
    color: '#53BDEB',
    fontWeight: '600',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 36,
    paddingVertical: 60,
    gap: 12,
  },
  emptyTitle: {
    color: '#E4E6EB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 8,
  },
  emptySubtitle: {
    color: '#B0B3B8',
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 18,
  },
  composerContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: '#242526',
    borderTopWidth: 1,
    borderTopColor: '#393A3B',
    gap: 8,
  },
  inputPill: {
    flex: 1,
    backgroundColor: '#3A3B3C',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: Platform.OS === 'ios' ? 8 : 4,
    minHeight: 40,
    maxHeight: 110,
    justifyContent: 'center',
  },
  input: {
    color: '#E4E6EB',
    fontSize: 15,
    padding: 0,
    maxHeight: 90,
  },
  sendBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#0084FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 1,
  },
  sendBtnDisabled: {
    opacity: 0.35,
  },
  sendIcon: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '900',
    marginLeft: 2,
  },
});
