import React, {useCallback, useEffect, useRef, useState} from 'react';
import {StatusBar, View, Alert, Text, ActivityIndicator, AppState, AppStateStatus} from 'react-native';
import {AuthScreen} from './src/screens/AuthScreen';
import {HomeScreen} from './src/screens/HomeScreen';
import {ChatScreen} from './src/screens/ChatScreen';
import {Chat, User} from './src/types';
import {demoChats, demoUsers} from './src/state/demoData';
import {clearDemoSession, clearLiveSession, readDemoSession, readLiveSession, saveDemoSession, saveLiveSession} from './src/services/session';
import {APP_CONFIG, isLiveConfigReady} from './src/config';
import {TlsSignalingClient} from './src/services/signaling';
import {ServerDataChannel, RtcStatus} from './src/services/rtc';
import {e2eeService, RemotePreKeyBundle} from './src/services/e2ee';
import {
  getLocalMessages,
  saveLocalMessages,
  appendLocalMessage,
  updateLocalMessageStatus,
} from './src/services/messageStore';
import {C, S} from './src/theme';
import {getMessageTimestamp} from './src/utils/time';

async function publishPrekeys(signal: TlsSignalingClient) {
  try {
    const bundle = await e2eeService.exportPreKeyBundle();
    await signal.request({type: 'publish_prekeys', bundle}, 'prekeys_published');
  } catch (err) {
    console.warn('Could not publish prekeys:', err);
  }
}

type Session = {uid?: string; username: string; displayName: string; about?: string; token?: string; live: boolean};
type InboxUser = {uid: string; username: string; display_name: string; about: string; online: boolean};
type InboxConversation = {conversation_id: string; user: InboxUser; unread_count: number; has_messages: boolean; updated_at: string};
type AuthResponse = {uid: string; username: string; display_name: string; about: string; token: string};

async function mapInbox(conversations: InboxConversation[]): Promise<Chat[]> {
  return Promise.all(conversations.map(async item => {
    const localMsgs = await getLocalMessages(item.conversation_id);
    const lastMsg = localMsgs.length > 0 ? localMsgs[localMsgs.length - 1] : null;
    const itemTimestamp = lastMsg?.timestamp || (Number(item.updated_at) ? Number(item.updated_at) * 1000 : Date.now());
    return {
      id: item.conversation_id,
      user: {id: item.user.uid, username: item.user.username, name: item.user.display_name, about: item.user.about, online: item.user.online},
      preview: lastMsg ? lastMsg.text : item.has_messages ? 'Encrypted message' : 'Start a conversation',
      time: lastMsg ? lastMsg.time : 'Recent',
      timestamp: itemTimestamp,
      unread: item.unread_count,
      messages: localMsgs,
    };
  }));
}

export default function App() {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [session, setSession] = useState<Session | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [chats, setChats] = useState<Chat[]>([]);
  const [selected, setSelected] = useState<Chat | null>(null);
  const selectedRef = useRef<Chat | null>(null);
  const [authBusy, setAuthBusy] = useState(false);
  const [rtcStatus, setRtcStatus] = useState<RtcStatus>('disconnected');
  const signalRef = useRef<TlsSignalingClient | null>(null);
  const rtcRef = useRef<ServerDataChannel | null>(null);

  useEffect(() => {
    selectedRef.current = selected;
  }, [selected]);

  const createRealtime = useCallback((signal: TlsSignalingClient) => {
    const rtc = new ServerDataChannel(signal);
    rtc.onConnectionStatus(setRtcStatus);
    rtc.onMessage(packet => {
      try {
        const envelope = JSON.parse(packet) as {
          type?: string;
          uid?: string;
          online?: boolean;
          message_id?: string;
          conversation_id?: string;
          user?: InboxUser;
          message?: {message_id: string; conversation_id: string; sender_uid: string; ciphertext_b64: string; created_at: string; status: string};
        };
        if (envelope.type === 'error') {
          console.warn('Transport notification:', packet);
        } else if (['saved_ack', 'delivered_ack', 'seen_ack'].includes(envelope.type || '') && envelope.message_id) {
          const nextStatus = envelope.type === 'saved_ack' ? 'saved' : envelope.type === 'delivered_ack' ? 'delivered' : 'seen';
          const msgId = envelope.message_id;
          const convId = envelope.conversation_id || selectedRef.current?.id;
          if (convId) {
            void updateLocalMessageStatus(convId, msgId, nextStatus as any);
          }
          setChats(current => current.map(item => ({
            ...item,
            messages: item.messages.map(message => message.id === msgId ? {...message, status: nextStatus as 'saved' | 'delivered' | 'seen'} : message),
          })));
          setSelected(current => current ? ({
            ...current,
            messages: current.messages.map(message => message.id === msgId ? {...message, status: nextStatus as 'saved' | 'delivered' | 'seen'} : message),
          }) : current);
        } else if (envelope.type === 'presence_update' && envelope.uid && typeof envelope.online === 'boolean') {
          const targetUid = envelope.uid;
          const isOnline = envelope.online!;
          const now = Date.now();
          setChats(current => current.map(item => item.user.id === targetUid ? {
            ...item,
            user: {
              ...item.user,
              online: isOnline,
              lastActive: isOnline ? undefined : (item.user.lastActive || now),
            },
          } : item));
          setSelected(current => {
            if (!current || current.user.id !== targetUid) return current;
            const updated = {
              ...current,
              user: {
                ...current.user,
                online: isOnline,
                lastActive: isOnline ? undefined : (current.user.lastActive || now),
              },
            };
            selectedRef.current = updated;
            return updated;
          });
        } else if (envelope.type === 'new_conversation' && envelope.conversation_id && envelope.user) {
          const newChat: Chat = {
            id: envelope.conversation_id,
            user: {id: envelope.user.uid, username: envelope.user.username, name: envelope.user.display_name, about: envelope.user.about, online: envelope.user.online},
            preview: 'Start a conversation', time: 'Now', timestamp: Date.now(), unread: 0, messages: [],
          };
          setChats(current => current.some(item => item.id === newChat.id) ? current : [newChat, ...current]);
        } else if (envelope.type === 'new_message' && envelope.message) {
          const incoming = envelope.message;
          const handleIncoming = async () => {
            // Acknowledge delivered receipt immediately
            try {
              rtc.sendControlFrame({type: 'delivered_ack', message_id: incoming.message_id});
            } catch {}

            const isCurrentChat = selectedRef.current?.id === incoming.conversation_id;
            if (isCurrentChat) {
              try {
                rtc.sendControlFrame({type: 'seen_ack', message_id: incoming.message_id});
              } catch {}
            }

            // Check if already decrypted locally (prevents double ratcheting on outbox retries)
            const existingLocal = await getLocalMessages(incoming.conversation_id);
            const alreadyDecrypted = existingLocal.find(m => m.id === incoming.message_id);
            if (alreadyDecrypted && !alreadyDecrypted.text.startsWith('Encrypted message') && !alreadyDecrypted.text.startsWith('Decryption failed')) {
              return;
            }

            let decryptedText = 'Encrypted message';
            try {
              decryptedText = await e2eeService.decrypt(incoming.sender_uid, 0, incoming.ciphertext_b64);
            } catch (err) {
              console.warn('Decryption failed:', err);
              if (alreadyDecrypted && !alreadyDecrypted.text.startsWith('Encrypted message')) {
                return;
              }
              decryptedText = 'Decryption failed · Bad MAC or missing session';
            }

            const incomingEpoch = Number(incoming.created_at) * 1000 || Date.now();
            const incomingMsg = {
              id: incoming.message_id,
              from: 'them' as const,
              text: decryptedText,
              time: new Date(incomingEpoch).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}),
              timestamp: incomingEpoch,
              status: isCurrentChat ? ('seen' as const) : ('delivered' as const),
            };

            await appendLocalMessage(incoming.conversation_id, incomingMsg);

            setChats(current => current.map(item => {
              if (item.id !== incoming.conversation_id) return item;
              const exists = item.messages.some(m => m.id === incoming.message_id);
              const msgs = exists ? item.messages.map(m => m.id === incoming.message_id ? incomingMsg : m) : [...item.messages, incomingMsg];
              return {
                ...item,
                preview: decryptedText,
                time: 'Now',
                timestamp: incomingEpoch,
                unread: isCurrentChat ? 0 : item.unread + 1,
                messages: msgs,
              };
            }));

            setSelected(current => {
              if (!current || current.id !== incoming.conversation_id) return current;
              const exists = current.messages.some(m => m.id === incoming.message_id);
              const msgs = exists ? current.messages.map(m => m.id === incoming.message_id ? incomingMsg : m) : [...current.messages, incomingMsg];
              const updatedChat = {
                ...current,
                preview: decryptedText,
                time: 'Now',
                timestamp: incomingEpoch,
                unread: 0,
                messages: msgs,
              };
              selectedRef.current = updatedChat;
              return updatedChat;
            });
          };
          void handleIncoming();
        }
      } catch {
        // Ignore malformed DataChannel payloads; never acknowledge an unverified message.
      }
    });
    return rtc;
  }, []);

  useEffect(() => {
    let cancelled = false;
    let bootSignal: TlsSignalingClient | null = null;
    let bootRtc: ServerDataChannel | null = null;

    const boot = async () => {
      try {
        const saved = await readLiveSession();
        if (!saved || cancelled) {
          setIsInitializing(false);
          return;
        }
        if (!isLiveConfigReady()) {
          setIsInitializing(false);
          return;
        }

        bootSignal = new TlsSignalingClient();
        await bootSignal.connect();
        const result = await bootSignal.request<AuthResponse>({type: 'resume', token: saved.token}, 'auth_ok');
        const inbox = await bootSignal.request<{conversations?: InboxConversation[]}>(
          {type: 'list_conversations'}, 'conversations');
        if (cancelled) { bootSignal.close(); return; }

        await saveLiveSession({uid: result.uid, username: result.username, displayName: result.display_name, about: result.about, token: result.token});
        if (cancelled) { bootSignal.close(); return; }
        signalRef.current = bootSignal;
        await publishPrekeys(bootSignal);
        bootRtc = createRealtime(bootSignal);
        rtcRef.current = bootRtc;
        setSession({uid: result.uid, username: result.username, displayName: result.display_name, about: result.about, token: result.token, live: true});
        setChats(await mapInbox(inbox.conversations || []));
        try {
          await bootRtc.connectAuthenticated();
        } catch {
          setRtcStatus('failed');
        }
      } catch (error) {
        bootRtc?.close();
        bootSignal?.close();
        await clearLiveSession();
        setSession(null);
      } finally {
        if (!cancelled) setIsInitializing(false);
      }
    };

    void boot().catch(() => {
      if (!cancelled) setIsInitializing(false);
    });

    return () => {
      cancelled = true;
      bootRtc?.close();
      bootSignal?.close();
    };
  }, [createRealtime]);

  useEffect(() => () => {
    rtcRef.current?.close();
    signalRef.current?.close();
  }, []);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (nextState: AppStateStatus) => {
      if (nextState === 'background' || nextState === 'inactive') {
        try {
          rtcRef.current?.sendControlFrame({type: 'presence_offline'});
        } catch {}
        rtcRef.current?.close();
        setRtcStatus('disconnected');
      } else if (nextState === 'active') {
        if (session?.live && signalRef.current?.connected) {
          const rtc = rtcRef.current || createRealtime(signalRef.current);
          rtcRef.current = rtc;
          rtc.connectAuthenticated().catch(() => {
            setRtcStatus('failed');
          });
        }
      }
    });
    return () => {
      sub.remove();
    };
  }, [session, createRealtime]);

  const searchPeople = useCallback(async (query: string): Promise<User[]> => {
    if (APP_CONFIG.DEMO_MODE) {
      return demoUsers.filter(user => `${user.name} ${user.username}`.toLowerCase().includes(query.toLowerCase()));
    }
    const signal = signalRef.current;
    if (!signal?.connected) throw new Error('Server signaling connection is not available');
    const response = await signal.request<{users?: Array<{uid: string; username: string; display_name: string; about: string; online: boolean}>}>(
      {type: 'search_users', query}, 'users');
    return (response.users || []).map(user => ({
      id: user.uid, username: user.username, name: user.display_name, about: user.about, online: user.online,
    }));
  }, []);

  const openChat = async (chat: Chat) => {
    // 1. Immediately display locally persisted decrypted messages
    const localMsgs = await getLocalMessages(chat.id);
    const initialMsgs = [...(localMsgs.length > 0 ? localMsgs : chat.messages)].sort(
      (a, b) => getMessageTimestamp(a) - getMessageTimestamp(b)
    );
    const lastM = initialMsgs.length > 0 ? initialMsgs[initialMsgs.length - 1] : null;
    const initialChat = {
      ...chat,
      unread: 0,
      preview: lastM ? lastM.text : chat.preview,
      timestamp: lastM?.timestamp || chat.timestamp || Date.now(),
      messages: initialMsgs,
    };
    setSelected(initialChat);
    selectedRef.current = initialChat;
    setChats(prev => prev.map(item => item.id === chat.id ? {...item, unread: 0} : item));

    // Send seen_ack for unread messages from peer
    for (const m of initialMsgs) {
      if (m.from === 'them' && m.status !== 'seen') {
        try {
          rtcRef.current?.sendControlFrame({type: 'seen_ack', message_id: m.id});
        } catch {}
      }
    }

    if (APP_CONFIG.DEMO_MODE) return;
    const signal = signalRef.current;
    if (!signal?.connected) return;

    try {
      const response = await signal.request<{
        messages?: Array<{message_id: string; sender_uid: string; ciphertext_b64: string; created_at: string; status: string}>;
      }>({
        type: 'conversation_history', conversation_id: chat.id,
      }, 'history');

      const serverMessages = response.messages || [];
      const localMap = new Map<string, any>();
      for (const m of initialMsgs) {
        localMap.set(m.id, m);
      }

      const merged: any[] = [];

      for (const sm of serverMessages) {
        const existing = localMap.get(sm.message_id);
        const serverStatus = (['SAVED', 'DELIVERED', 'SEEN'].includes(sm.status)
          ? sm.status.toLowerCase()
          : 'saved') as 'saved' | 'delivered' | 'seen';

        const smTimestamp = Number(sm.created_at) * 1000 || Date.now();

        if (existing && !existing.text.startsWith('Encrypted message') && !existing.text.startsWith('Decryption failed')) {
          // Already decrypted and stored locally! Keep the plaintext!
          merged.push({
            ...existing,
            timestamp: existing.timestamp || smTimestamp,
            status: serverStatus,
          });
        } else {
          // New message not yet decrypted
          let text = existing?.text || 'Encrypted message';
          if (sm.sender_uid === session?.uid) {
            text = existing?.text && !existing.text.startsWith('Encrypted message')
              ? existing.text
              : 'Sent message';
          } else {
            try {
              text = await e2eeService.decrypt(sm.sender_uid, 0, sm.ciphertext_b64);
            } catch {
              text = existing?.text || 'Encrypted message';
            }
          }
          merged.push({
            id: sm.message_id,
            from: sm.sender_uid === session?.uid ? 'me' as const : 'them' as const,
            text,
            time: new Date(smTimestamp).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}),
            timestamp: smTimestamp,
            status: serverStatus,
          });
        }
      }

      // Preserve any optimistic messages not yet returned by server history
      for (const m of initialMsgs) {
        if (!merged.some(item => item.id === m.id)) {
          merged.push(m);
        }
      }

      // Ensure chronological ordering across all messages
      merged.sort((a, b) => {
        const timeA = getMessageTimestamp(a);
        const timeB = getMessageTimestamp(b);
        if (timeA !== timeB) return timeA - timeB;
        return a.id.localeCompare(b.id);
      });

      await saveLocalMessages(chat.id, merged);
      const lastMerged = merged.length > 0 ? merged[merged.length - 1] : null;
      const updated = {
        ...chat,
        unread: 0,
        preview: lastMerged ? lastMerged.text : chat.preview,
        timestamp: lastMerged?.timestamp || chat.timestamp,
        messages: merged,
      };
      setSelected(current => current?.id === chat.id ? updated : current);
      selectedRef.current = updated;
      setChats(prev => prev.map(item => item.id === chat.id ? updated : item));

      // Acknowledge seen for any incoming messages in the merged history
      for (const m of merged) {
        if (m.from === 'them' && m.status !== 'seen') {
          try {
            rtcRef.current?.sendControlFrame({type: 'seen_ack', message_id: m.id});
          } catch {}
        }
      }
    } catch (error) {
      console.warn('Could not load history:', error);
    }
  };

  const addChat = async (user: User) => {
    try {
      let conversationId = `c_${user.id}`;
      if (!APP_CONFIG.DEMO_MODE) {
        const signal = signalRef.current;
        if (!signal?.connected) throw new Error('Server signaling is disconnected');
        const response = await signal.request<{conversation_id: string}>(
          {type: 'create_conversation', other_uid: user.id}, 'conversation');
        conversationId = response.conversation_id;
      }
      const existing = chats.find(chat => chat.id === conversationId || chat.user.id === user.id);
      if (existing) { openChat(existing); return; }
      const newChat: Chat = {id: conversationId, user, preview: 'Start a conversation', time: 'Now', timestamp: Date.now(), unread: 0, messages: []};
      setChats(prev => [newChat, ...prev]);
      await openChat(newChat);
    } catch (error) {
      Alert.alert('Could not open conversation', error instanceof Error ? error.message : 'Please try again.');
    }
  };

  const sendMessage = async (text: string) => {
    if (!selected) return;
    const recipientUid = selected.user.id;
    const conversationId = selected.id;
    const signal = signalRef.current;
    const rtc = rtcRef.current;

    const now = Date.now();
    const tempMsgId = `m_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const tempMsg = {
      id: tempMsgId,
      from: 'me' as const,
      text,
      time: new Date(now).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'}),
      timestamp: now,
      status: 'saved' as const,
    };

    // 1. Immediately persist plaintext to local device store
    const updatedMessages = await appendLocalMessage(conversationId, tempMsg as any);
    const updated = {...selected, preview: text, time: 'Now', timestamp: now, unread: 0, messages: updatedMessages};
    setSelected(updated);
    selectedRef.current = updated;
    setChats(prev => [updated, ...prev.filter(chat => chat.id !== selected.id)]);

    try {
      const hasSession = await e2eeService.hasSession(recipientUid);
      if (!hasSession) {
        if (!signal?.connected) throw new Error('Signaling server is not connected');
        const res = await signal.request<{uid: string; bundle: RemotePreKeyBundle}>(
          {type: 'get_prekey_bundle', uid: recipientUid},
          'prekey_bundle'
        );
        if (!res.bundle) throw new Error('Recipient has not published encryption prekeys');
        await e2eeService.establishSessionWithPeer(recipientUid, res.bundle);
      }

      const {body_b64} = await e2eeService.encrypt(recipientUid, text);
      if (!rtc) throw new Error('WebRTC transport is unavailable');
      const payload = JSON.stringify({
        type: 'send_message',
        message_id: tempMsgId,
        conversation_id: conversationId,
        ciphertext_b64: body_b64,
      });
      rtc.sendEncryptedEnvelope(payload);
    } catch (err) {
      Alert.alert('Send failed', err instanceof Error ? err.message : String(err));
    }
  };

  const submitAuth = async (name: string, username: string, password: string) => {
    if (authBusy) return;
    setAuthBusy(true);
    let pendingSignal: TlsSignalingClient | null = null;
    try {
      if (!username.trim() || !password) {
        throw new Error('Invalid username or password.');
      }
      if (!isLiveConfigReady()) {
        throw new Error('Set the real Rust signaling hostname and ICE server in mobile/src/config.ts first.');
      }

      // Proactively clear any stale/residual session credentials before authenticating fresh
      await clearLiveSession();
      await clearDemoSession();

      pendingSignal = new TlsSignalingClient();
      await pendingSignal.connect();
      const authFrame = mode === 'register'
        ? {type: 'register', username: username.trim().toLowerCase(), display_name: name.trim() || username.trim(), password}
        : {type: 'login', username: username.trim().toLowerCase(), password};

      const result = await pendingSignal.request<AuthResponse>(authFrame, 'auth_ok');
      if (!result?.token || !result?.uid) {
        throw new Error('Invalid username or password.');
      }

      const inbox = await pendingSignal.request<{conversations?: Array<{conversation_id: string; user: {uid: string; username: string; display_name: string; about: string; online: boolean}; unread_count: number; has_messages: boolean; updated_at: string}>}>(
        {type: 'list_conversations'}, 'conversations');

      await saveLiveSession({
        uid: result.uid,
        username: result.username,
        displayName: result.display_name,
        about: result.about,
        token: result.token,
      });

      signalRef.current = pendingSignal;
      await publishPrekeys(pendingSignal);
      const rtc = createRealtime(pendingSignal);
      rtcRef.current = rtc;
      setSession({
        uid: result.uid,
        username: result.username,
        displayName: result.display_name,
        about: result.about,
        token: result.token,
        live: true,
      });
      setChats(await mapInbox(inbox.conversations || []));

      try {
        await rtc.connectAuthenticated();
      } catch {
        setRtcStatus('failed');
      }
      pendingSignal = null;
    } catch (error) {
      pendingSignal?.close();
      if (signalRef.current === pendingSignal) signalRef.current = null;
      await clearLiveSession();
      setSession(null);
      const msg = error instanceof Error ? error.message : String(error);
      if (
        msg.toLowerCase().includes('password') ||
        msg.toLowerCase().includes('username') ||
        msg.toLowerCase().includes('login_failed') ||
        msg.toLowerCase().includes('invalid') ||
        msg.toLowerCase().includes('credentials')
      ) {
        throw new Error('Invalid username or password.');
      }
      throw error;
    } finally {
      setAuthBusy(false);
    }
  };

  const updateProfile = async (displayName: string, about: string) => {
    if (!session?.live) throw new Error('Profile editing requires a live server account.');
    const signal = signalRef.current;
    if (!signal?.connected) throw new Error('Server connection is unavailable.');
    const response = await signal.request<{user: {display_name: string; about: string}}>({
      type: 'update_profile', display_name: displayName, about,
    }, 'profile_updated');
    setSession(current => current ? {...current, displayName: response.user.display_name, about: response.user.about} : current);
    if (session.token && session.uid) {
      await saveLiveSession({uid: session.uid, username: session.username, displayName: response.user.display_name, about: response.user.about, token: session.token});
    }
  };

  const logout = async () => {
    const activeSignal = signalRef.current;
    if (session?.live && activeSignal?.connected) {
      try { await activeSignal.request({type: 'logout'}, 'logged_out', 5000); } catch {}
    }
    rtcRef.current?.close();
    rtcRef.current = null;
    signalRef.current?.close();
    signalRef.current = null;
    setRtcStatus('disconnected');
    await clearLiveSession();
    await clearDemoSession();
    setSession(null);
    setSelected(null);
    setChats([]);
    setMode('login');
  };

  return <View style={{flex: 1, backgroundColor: C.bg}}>
    <StatusBar barStyle="light-content"/>
    {isInitializing ? (
      <View style={[S.screen, {justifyContent: 'center', alignItems: 'center'}]}>
        <ActivityIndicator size="large" color={C.green}/>
        <Text style={{color: C.muted, marginTop: 14, fontSize: 13}}>Restoring secure session...</Text>
      </View>
    ) : selected && session ? (
      <ChatScreen chat={selected} liveMode={session.live} rtcStatus={rtcStatus} onBack={() => { setSelected(null); selectedRef.current = null; }} onSend={sendMessage}/>
    ) : session ? (
      <HomeScreen
        username={session.username}
        uid={session.uid}
        displayName={session.displayName}
        about={session.about}
        liveMode={session.live}
        rtcStatus={rtcStatus}
        chats={chats}
        people={[]}
        onSearchPeople={searchPeople}
        onOpenChat={openChat}
        onLogout={logout}
        onAddChat={user => { void addChat(user); }}
        onUpdateProfile={updateProfile}
      />
    ) : (
      <AuthScreen mode={mode} onMode={setMode} onSubmit={submitAuth} busy={authBusy} demoMode={APP_CONFIG.DEMO_MODE}/>
    )}
  </View>;
}
